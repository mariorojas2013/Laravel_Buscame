<?php $__env->startSection('title'); ?>
Panel de busqueda  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content1'); ?>
<style>
    .w-espe{
    width: 21rem;
    }
</style>
                    <img src="<?php echo e(url('images/busFonTrans-10.png')); ?>" alt="" style="width: 189px;" />
                            <h2>Red social de personas desaparecidas.</h2>
                             <?php if($busqueda_tipo =='interna'): ?>
                            <a href="<?php echo e(url('busqueda')); ?>" class="icon solid fa-search"> Panel de busqueda</a>
                             <?php else: ?>
                            <a href="<?php echo e(url('registro_des')); ?>" class="icon solid fa-address-card"> Registro desaparecidos</a>
                            <?php endif; ?>

                     
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>

  <header class="major">
                            <h2>Busqueda: </h2>
                           
                           

                        </header>
                        <form method="post" action="#">
                                    <div class="row gtr-uniform gtr-50">
                                        <div class="col-12"><input type="text" name="usuario" id="usuario" placeholder="Buscar" /><br>
                                        
                                    </div>
                                </form>
                          
                            <?php if($busqueda_tipo =='interna'): ?>
                                 <a href="<?php echo e(url('registro_add_desa')); ?>" class="icon solid fa-plus-circle fa-3"> Reportar persona desaparecida</a>


                                 
                            <?php endif; ?>
                 
                        <div class="row">

                        	<?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                         	 <div class="card w-espe" style=" margin: 10px;">
                              <div class="card-body">

                                <!-- <h4 style="color:#9e1842">DESAPARECIDO(A)</h4> -->
                                <h5 class="card-title"><?php echo e($per->nombres); ?> <?php echo e($per->apellidos); ?></h5>
                                <article class="col-12-xsmall work-item">
                                  

                                      <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                                          <div class="carousel-inner">
                                            <div class="carousel-item active">
                                              <img class="d-block w-100" src="<?php echo e(url(  'images/publicaciones/full/'.$per->numero_documento.'_1.png' )); ?>" alt="First slide">
                                            </div>
                                            <div class="carousel-item">
                                              <img class="d-block w-100" src="<?php echo e(url(  'images/publicaciones/full/'.$per->numero_documento.'_2.png' )); ?>" alt="Second slide">
                                            </div>
                                            <div class="carousel-item">
                                              <img class="d-block w-100" src="<?php echo e(url(  'images/publicaciones/full/'.$per->numero_documento.'_3.png' )); ?>" alt="Third slide">
                                            </div>
                                          </div>
                                          <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                            <span class="sr-only">Previous</span>
                                          </a>
                                          <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                            <span class="sr-only">Next</span>
                                          </a>
                                        </div>  
 
                                    <h3><span class="icon solid fa-calendar"></span> fecha de nacimiento: <?php echo e($per->fecha_nacimiento); ?></h3>
                                    <h3><span class="icon solid fa-eye"></span> color de ojos: <?php echo e($per->color_ojos); ?> </h3>
                                    <h3><span class="icon solid fa-tint"></span> color de cabello: <?php echo e($per->color_cabello); ?> </h3>
                                    <h3><span class="icon solid fa-tint"></span> color de piel: <?php echo e($per->color_piel); ?> </h3>
                                    <h3><span class="icon solid fa-database"></span> peso promedio: <?php echo e($per->peso_promedio); ?> </h3>
                                    <h3><span class="icon solid fa-mars"></span> género: <?php echo e($per->genero); ?> </h3>
                                    <h3><span class="icon solid fa-arrow-up"></span> estatura: <?php echo e($per->estatura); ?> </h3>
                                    <h3><span class="icon solid fa-heartbeat"></span> enfermedades: <?php echo e($per->enfermedades); ?> </h3>
                                    <h3><span class="icon solid fa-map-marker"></span> última ubicación: <?php echo e($per->ultima_ubicacion); ?> </h3>
                                    <h3><span class="icon solid fa-retweet"></span> estado: <?php echo e($per->estado); ?> </h3>

                                    
                                   
                                </article>
                                <?php if($busqueda_tipo =='interna'): ?>
                                    <ul class="icons">
                                        <?php if($busqueda_tipo !='Revision'): ?>
                                            <li><a href="<?php echo e(url('editar_reg_desa')); ?>/<?php echo e($per->id_desaparecido); ?>" class="icon solid fa-pencil-square-o"> Editar</a></li>
                                        <?php endif; ?>
                                        <?php if($busqueda_tipo !='Revision'): ?>
                                            <?php if($busqueda_tipo =='Registro'): ?>
                                            <li><a href="<?php echo e(url('publicar_reg_desa')); ?>/<?php echo e($per->id_desaparecido); ?>" class="icon solid fa-cloud"> Publicar</a></li>
                                            <?php else: ?>
                                            <li><a href="<?php echo e(url('Qpublicar_reg_desa')); ?>/<?php echo e($per->id_desaparecido); ?>" class="icon solid fa-cloud"> Quitar Publicacion</a></li>
                                            <?php endif; ?>

                                        <?php endif; ?>
                                        <?php if($busqueda_tipo !='Revision'): ?>
                                        <li><a href="<?php echo e(url('eliminar_reg_desa')); ?>/<?php echo e($per->id_desaparecido); ?>" class="icon solid fa-trash"> Eliminar</a></li>
                                        <?php endif; ?>
                                        <?php if($busqueda_tipo !='Revision'): ?>
                                        <li><a href="<?php echo e(url('ver_mensajes_desa')); ?>/<?php echo e($per->id_desaparecido); ?>" class="icon solid fa-commenting"> Ver mensajes</a></li>
                                        <?php endif; ?>

                                    </ul>
                                
                                <?php else: ?>
                                <ul class="icons">
                                     <li><a href="<?php echo e(url('mas')); ?>/<?php echo e($per->id_desaparecido); ?>" class="icon solid fa-arrow-right"> Ver más</a></li>

                                     <li><a href="<?php echo e(url('mensajes')); ?>/<?php echo e($per->id_desaparecido); ?>" class="icon solid fa-commenting"> Enviar mensajes</a></li>
                                </ul>
                                <?php endif; ?>
                              </div> 
                            </div>
                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <div class="MensajeRegistros" style='display:none'>
                                No se encontraron registros
                            </div>

 
                             
                        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptPropio'); ?>

 <script>
     $('#usuario').keyup(function () {
 
                    var rex = new RegExp($(this).val(), 'i');
                    $('.card').hide();
                    $('.MensajeRegistros').hide();

                    $('.card').filter(function () {
                        return rex.test($(this).text());
                    }).show();
                    if($(".card").filter(":visible").length == 0 )
                    {
                        $('.MensajeRegistros').show();
                    }

                })


                <?php if(Session::get('nombres')==""): ?>
                    window.location.href  ="<?php echo e(url('/')); ?>";
                <?php endif; ?>
          
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>