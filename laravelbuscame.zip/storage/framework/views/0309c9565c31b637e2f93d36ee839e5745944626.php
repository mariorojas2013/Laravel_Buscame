<?php $__env->startSection('title'); ?>
Registro
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content1'); ?>
                    <img src="<?php echo e(url('images/busFonTrans-10.png')); ?>" alt="" style="width: 189px;" />
                            <h2>Red social de personas desaparecidas.</h2>
                            <?php if($comand == 'edit'): ?>
                             Editando
                            <?php endif; ?>

                            <?php if($comand == 'add'): ?>
                             Agregando
                            <?php endif; ?>

                            <?php if($comand == 'ver'): ?>
                             Ver mas
                            <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>
  <header class="major">
                            <h2>Datos persona desaparecida.</h2>
                                <a href="<?php echo e(url('registro_des')); ?>" class="icon solid fa-arrow-left"> Volver</a>
                            
                        </header>
                      
                        <div class="row">

                        	

                            <?php if($comand == 'edit'): ?>
                             <form action="<?php echo e(url('save_edit_desa')); ?>"  method="post">
                            <?php endif; ?>

                            <?php if($comand == 'add'): ?>
                             <form action="<?php echo e(url('save_desa')); ?>" method="post">
                            <?php endif; ?>
                             <?php echo e(csrf_field()); ?>

                                
                         	 <div class="card" style="width: 24rem; margin: 10px;">
                              <div class="card-body">

                                <!-- <h4 style="color:#9e1842">DESAPARECIDO(A)</h4> -->
                              
                                <article class="col-12-xsmall work-item">
                                    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                                          <div class="carousel-inner">
                                            <div class="carousel-item active">
                                              <img class="d-block w-100" src="<?php echo e(url(  'images/publicaciones/full/'.$pro->numero_documento.'_1.png' )); ?>" alt="First slide">
                                            </div>
                                            <div class="carousel-item">
                                              <img class="d-block w-100" src="<?php echo e(url(  'images/publicaciones/full/'.$pro->numero_documento.'_2.png' )); ?>" alt="Second slide">
                                            </div>
                                            <div class="carousel-item">
                                              <img class="d-block w-100" src="<?php echo e(url(  'images/publicaciones/full/'.$pro->numero_documento.'_3.png' )); ?>" alt="Third slide">
                                            </div>
                                          </div>
                                          <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                            <span class="sr-only">Previous</span>
                                          </a>
                                          <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                            <span class="sr-only">Next</span>
                                          </a>
                                        </div>

                                    <input type="hidden" name="id_desaparecido" value="<?php echo e($id); ?>">
                                    

                                    <br>
                                    Tipo documento
                                    <select name="tipo_documento" id="tipo_documento" <?php echo e(($comand=='ver'?'disabled':'')); ?>>
                                         <option value="CC">Cedula de Ciudadania</option> 
                                         <option value="TI">Tarjeta de identidad</option> 
                                         <option value="RC">Registro civil</option> 
                                         <option value="CE">Cedula Extranjeria</option> 
                                         <option value="PA">Pasaporte</option> 
                                    </select> 
                                    <br>
                                    Número de documento
                                    <input type="text" name="numero_documento" value="<?php echo e(isset($pro)?$pro->numero_documento:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Nombres
                                    <input type="text" name="nombres" value="<?php echo e(isset($pro)?$pro->nombres:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    apellidos
                                    <input type="text" name="apellidos" value="<?php echo e(isset($pro)?$pro->apellidos:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Fecha de nacimiento <br>
                                    <input type="date" name="fecha_nacimiento" format="yyyy-MM-dd" style='width: 100%; border-radius: 10px;padding: 6px;'  value="<?php echo e(isset($pro)?$pro->fecha_nacimiento:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Color de ojos
                                    <input type="text" name="color_ojos" value="<?php echo e(isset($pro)?$pro->color_ojos:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Color de cabello
                                    <input type="text" name="color_cabello" value="<?php echo e(isset($pro)?$pro->color_cabello:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Color de piel
                                    <input type="text" name="color_piel" value="<?php echo e(isset($pro)?$pro->color_piel:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                                                        <br>
                                    Peso promedio
                                    <input type="text" name="peso_promedio" value="<?php echo e(isset($pro)?$pro->peso_promedio:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                                                        <br>
                                    Genero
                                    <select name="genero" id="genero" <?php echo e(($comand=='ver'?'disabled':'')); ?>>
                                         <option value="M">Masculino</option> 
                                         <option value="F">Femenino</option> 
                                         <option value="ND">No definido</option> 
                                    </select> 
                                                                        <br>
                                    Estatura
                                    <input type="text" name="estatura" value="<?php echo e(isset($pro)?$pro->estatura:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                                                        <br>
                                    Enfermedades
                                    <input type="text" name="enfermedades" value="<?php echo e(isset($pro)?$pro->enfermedades:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                                                        <br>
                                    Última ubicación
                                    <input type="text" name="ultima_ubicacion" value="<?php echo e(isset($pro)?$pro->ultima_ubicacion:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <div id="map-canvas"></div>
                                                                        <br>
                                    Estado
                                     <h3><?php echo e(isset($pro)?$pro->estado:''); ?></h3>

                                     
                                    
                                </article>
                                <?php if($comand == 'add' || $comand == 'edit'): ?>
                                        <input class="button solid primary " type="submit" name="" value="Guardar">
                                 <?php endif; ?>
                               
                              </div> 
                            </div>
                            </form>
                        	

 
                             
                        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptPropio'); ?>
<script src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script>
    <?php if($pro): ?>
    $("#tipo_documento").val('<?php echo e(isset($pro)?$pro->tipo_documento:''); ?>').change();
    $("#genero").val('<?php echo e(isset($pro)?$pro->genero:''); ?>').change();

    <?php endif; ?>

function initialize() {

    var myLatLng = new google.maps.LatLng(<?php echo e($pro->ultima_ubicacion); ?>),
        myOptions = {
            zoom: 15,
            center: myLatLng,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        },
        map = new google.maps.Map(document.getElementById('map-canvas'), myOptions),
        marker = new google.maps.Marker({
            position: myLatLng,
            map: map
        });

    marker.setMap(map);
    moveMarker(map, marker);

}

function moveMarker(map, marker) {

    //delayed so you can see it move
    setTimeout(function () {

        marker.setPosition(new google.maps.LatLng(<?php echo e($pro->ultima_ubicacion); ?>));
        map.panTo(new google.maps.LatLng(<?php echo e($pro->ultima_ubicacion); ?>));

    }, 1500);

};

initialize();
</script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>