﻿<!DOCTYPE HTML>
 <html>
	<head>
		<title><?php echo $__env->yieldContent('title'); ?></title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />

  		<link rel="stylesheet" href="<?php echo e(url('css/cssfont/font-awesome.css')); ?>">
  		<link rel="stylesheet" href="<?php echo e(url('css/main.css')); ?>">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	</head>
	<body class="is-preload">

		<!-- Header -->
			<header id="header">
				<div class="inner">
					<?php echo $__env->yieldContent('content1'); ?>
				</div>
			</header>

		<!-- Main -->
			<div id="main">
				<?php if(Session::get('nombres')): ?>
				<div class='global'>
					<a href="<?php echo e(url('ver_user')); ?>" class="icon solid fa-plus-circle fa-3"> Ver perfil de <?php echo e(Session::get('nombres')); ?></a>
				<br>
				<a href="<?php echo e(url('cerrarSesion')); ?>" class="icon solid fa-plus-circle fa-3"> Cerrar Sesión </a>
				</div>
				<?php endif; ?>
				<section id="one">
					<?php echo $__env->yieldContent('content2'); ?>
				</section>
				
		<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<ul class="icons">
						<li><a href="#" class="icon brands fa-facebook"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon brands fa-google"><span class="label">Github</span></a></li>
					</ul>
					 
				</div>
			</footer>
		
		<!-- Scripts -->
			<script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
			<script src="<?php echo e(url('js/jquery.poptrox.min.js')); ?>"></script>
			<script src="<?php echo e(url('js/browser.min.js')); ?>"></script>
			<script src="<?php echo e(url('js/breakpoints.min.js')); ?>"></script>
			<script src="<?php echo e(url('js/util.js')); ?>"></script>
			<script src="<?php echo e(url('js/main.js')); ?>"></script>
			<?php echo $__env->yieldContent('scriptPropio'); ?>
			

	</body>
</html>