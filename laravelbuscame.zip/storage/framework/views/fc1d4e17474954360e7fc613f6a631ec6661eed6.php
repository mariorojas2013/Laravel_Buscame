<?php $__env->startSection('title'); ?>
   Bienvenido, Red Social para las personas desaparecidas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content1'); ?>
                    <img src="<?php echo e(url('images/busFonTrans-10.png')); ?>" alt="" style="width: 189px;" />
                    <?php if($comand == 'edit'): ?>
                    <?php else: ?>
                     <form method="post" action="<?php echo e(url('iniciar')); ?>">
                        <?php echo e(csrf_field()); ?>


                                    <div class="row gtr-uniform gtr-50">
                                        <div class="col-12"><input type="text" autocomplete="off" name="usuario" id="usuario" placeholder="Usuario" /><br>
                                        <input type="password" name="clave" autocomplete="off" id="clave" placeholder="Clave" /></div>
                                        <div class="col-12"> <input type="submit" name="" value="Iniciar Sesión"></div>
                                    </div>
                                </form>
                    <?php endif; ?>
                   
                                <div class="error"> 
                                   <?php echo e(Session::get('error')); ?>

                                </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>
<?php if(isset($mensajes_user)): ?>
<br>
<h2><?php echo e($mensajes_user); ?></h2>
<br>
Ahora Inicia Sesión!
<br>
<br>
<?php else: ?>

                            <?php if($comand == 'edit'): ?>
                             <a href="<?php echo e(url('registro_des')); ?>" class="icon solid fa-arrow-left"> Volver</a>
                             <br>
                            <h3> Datos usuario</h3>
                             <form action="<?php echo e(url('save_edit_user')); ?>"  method="post">
                              <?php echo e(csrf_field()); ?>

                            <?php endif; ?>

                            <?php if($comand == 'add'): ?>
                            <h3> Registrate ya!</h3>

                             <form action="<?php echo e(url('save_user')); ?>" method="post">
                              <?php echo e(csrf_field()); ?>

                            <?php endif; ?>
                             
                                
                           <div class="card" style="width: 24rem; margin: 10px;">
                              <div class="card-body">

                                <!-- <h4 style="color:#9e1842">DESAPARECIDO(A)</h4> -->
                              
                                <article class="col-12-xsmall work-item">
                                  <?php if(isset($id)): ?>
                                   <input type="hidden" name="id" value="<?php echo e($id); ?>">
                                  <?php endif; ?>
                                    

                                    <br>
                                    Tipo documento
                                    <select name="tipo_documento" id="tipo_documento" <?php echo e(($comand=='ver'?'disabled':'')); ?>>
                                         <option value="CC">Cedula de Ciudadania</option> 
                                         <option value="TI">Tarjeta de identidad</option> 
                                         <option value="RC">Registro civil</option> 
                                         <option value="CE">Cedula Extranjeria</option> 
                                         <option value="PA">Pasaporte</option> 
                                    </select> 
                                    <br>
                                    Número de documento
                                    <input type="text" name="numero_documento" value="<?php echo e(isset($pro)?$pro->numero_documento:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Nombres
                                    <input type="text" name="nombres" value="<?php echo e(isset($pro)?$pro->nombres:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    apellidos
                                    <input type="text" name="apellidos" value="<?php echo e(isset($pro)?$pro->apellidos:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Ciudad de residencia
                                    <input type="text" name="ciudad_residencia" value="<?php echo e(isset($pro)?$pro->ciudad_residencia:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Telefono fijo
                                    <input type="text" name="telefono_fijo" value="<?php echo e(isset($pro)?$pro->telefono_fijo:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Celular
                                    <input type="text" name="celular" value="<?php echo e(isset($pro)?$pro->celular:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Email
                                    <input type="text" name="email" value="<?php echo e(isset($pro)?$pro->email:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Direccion
                                    <input type="text" name="direccion" value="<?php echo e(isset($pro)?$pro->direccion:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Usuario
                                    <input type="text" name="usuario" value="<?php echo e(isset($pro)?$pro->usuario:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    Clave
                                    <input type="text" name="clave" value="<?php echo e(isset($pro)?$pro->clave:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                    <br>
                                    <br>
                                    <br>
                                    <?php if(isset($id)): ?>
                                       Filtros de busqueda
                                      <input type="text" name="filtros" value="<?php echo e(isset($pro)?$pro->filtros:''); ?>" <?php echo e(($comand=='ver'?'ReadOnly="ReadOnly"':'')); ?>>
                                      <br>
                                   <?php endif; ?>
                                    
                                    
                                </article>
                                <?php if($comand == 'add' || $comand == 'edit'): ?>
                                        <input class="button solid primary " type="submit" name="" value="Guardar">
                                 <?php endif; ?>
                               
                              </div> 
                            </div>
                            </form>
<?php endif; ?>
                            
  <?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptPropio'); ?>

 
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>