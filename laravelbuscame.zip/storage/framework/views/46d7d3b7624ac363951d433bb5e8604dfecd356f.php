<?php $__env->startSection('title'); ?>
Mensajes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content1'); ?>
                    <img src="<?php echo e(url('images/busFonTrans-10.png')); ?>" alt="" style="width: 189px;" />
                            <h2>Red social de personas desaparecidas.</h2>
                            <h1>Mensajes.</h1>
                    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>
  <header class="major">
                        </header>
                                 
                                <a href="<?php echo e(url('registro_des')); ?>" class="icon solid fa-arrow-left"> Volver</a>
                 <h3 style="color:#9e1842">Desaparecido : <?php echo e($nombreDesa); ?></h3>
                                <br>
                        <div class="row">
                             <div class="card" style="width: 24rem; margin: 10px;">
                              <div class="card-body">
                                



                                <h4 style="color:#9e1842">Enviar mensajes</h4>
                                
                                <article class="col-12-xsmall work-item">
                                   <form method="post" action="<?php echo e(url('enviar_mensaje')); ?>">
                                    <?php echo e(csrf_field()); ?>


                                    <div class="row gtr-uniform gtr-50">
                                        <div class="col-12">
                                          <input type="text" name="mensaje" id="mensaje" placeholder="mensaje..." />
                                          <input type="hidden" name="id_desaparecido" value="<?php echo e($id_desaparecido); ?>" />
                                          <input type="hidden" name="id_usuario_envia" value="<?php echo e($id_usuario_envia); ?>" />
                                          <br>
                                        <div class="col-12"> <input type="submit" name="" value="Enviar"></div>
                                    </div>
                                </form> 
                                </article>
                                 
                              </div> 
                            </div>
                        	<?php $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $men): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                         	 <div class="card" style="width: 24rem; margin: 10px;">
                              <div class="card-body">
                                <h5 class="card-title">Mensaje enviado por <?php echo e($men->nombres); ?> <?php echo e($men->apellidos); ?></h5>
                                <article class="col-12-xsmall work-item">
                                    <h2><span class="icon solid fa-commenting"></span><?php echo e($men->mensaje); ?></h2>
                                </article>
                                
                              </div> 
                            </div>
                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

 
                             
                        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptPropio'); ?>

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>