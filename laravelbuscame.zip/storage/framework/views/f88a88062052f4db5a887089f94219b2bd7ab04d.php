<?php $__env->startSection('title'); ?>

   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content1'); ?>
                    <img src="<?php echo e(url('images/busFonTrans-10.png')); ?>" alt="" style="width: 189px;" />
                            <h2>Red social de personas desaparecidas.</h2>
                            <a href="#" class="icon solid fa-download">Registro desaparecidos</a>
                            <br>
                            <a href="#" class="icon solid fa-download">Panel de Busqueda </a>
                    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>
  <header class="major">
                            <h2>Red social de personas desaparecidas.</h2>
                        </header>
                        <form method="post" action="#">
                                    <div class="row gtr-uniform gtr-50">
                                        <div class="col-12"><input type="text" name="usuario" id="usuario" placeholder="Buscar" /><br>
                                        
                                    </div>
                                </form>
                          
                                      
                 
                        <div class="row">

                        	<?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                         	 <div class="card" style="width: 24rem; margin: 10px;">
                              <div class="card-body">

                                <h4 style="color:#9e1842">DESAPARECIDO(A)</h4>
                                <h5 class="card-title"><?php echo e($per->nombres); ?> <?php echo e($per->apellidos); ?></h5>
                                <article class="col-12-xsmall work-item">
                                    <a href="#" class="image fit thumb"><img src="<?php echo e(url('images/publicaciones/thumbs/123_1.png')); ?>" alt="" /></a>
                                    <h3><span class="icon solid fa-download"></span> fecha de nacimiento: <?php echo e($per->fecha_nacimiento); ?></h3>
                                    <h3><span class="icon solid fa-download"></span> color de ojos: <?php echo e($per->color_ojos); ?> </h3>
                                    <h3><span class="icon solid fa-download"></span> color de cabello: <?php echo e($per->color_cabello); ?> </h3>
                                    <h3><span class="icon solid fa-download"></span> color de piel: <?php echo e($per->color_piel); ?> </h3>
                                    <h3><span class="icon solid fa-download"></span> peso promedio: <?php echo e($per->peso_promedio); ?> </h3>
                                    <h3><span class="icon solid fa-download"></span> género: <?php echo e($per->genero); ?> </h3>
                                    <h3><span class="icon solid fa-download"></span> estatura: <?php echo e($per->estatura); ?> </h3>
                                    <h3><span class="icon solid fa-download"></span> enfermedades: <?php echo e($per->enfermedades); ?> </h3>
                                    <h3><span class="icon solid fa-download"></span> última ubicación: <?php echo e($per->ultima_ubicacion); ?> </h3>
                                    <h2><span class="icon solid fa-download"></span> Informe al fijo <?php echo e($per->telefono_fijo); ?> y celular <?php echo e($per->celular); ?> </h2>
                                    
                                </article>
                                <ul class="icons">
                                    <li><a href="<?php echo e(url('mensajes')); ?>/<?php echo e($per->id_desaparecido); ?>" class="icon solid fa-download">Enviar mensaje</a></li>
                                </ul>
                              </div> 
                            </div>
                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

 
                             
                        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptPropio'); ?>

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>